alert('Hello JavaScript');
