import { TextHighlightDirective } from './text-highlight.directive';

describe('TextHighlightDirective', () => {
  it('should create an instance', () => {
    // const directive = new TextHighlightDirective();
    // expect(directive).toBeTruthy();
  });
});
