let studentNames: string[];
let rollNumbers: number[];

studentNames = ['Shiva', 'John', 'David', 'Sasi'];
rollNumbers = [1, 2, 3, 4];

console.log(studentNames);
console.log(rollNumbers);
