/**
 * Date object
 */
var dateObj = new Date();

// console.log(dateObj.toLocaleString());

// console.log(dateObj.toString());

// console.log(dateObj.getDate());
// console.log(dateObj.getTime());
// console.log(dateObj.getDay());
// console.log(dateObj.getHours());
// console.log(dateObj.getMinutes());

// setInterval(() => {
//   var dateObj2 = new Date();
//   console.log(dateObj2.toLocaleString());
// }, 1000);

/**
 * Math object
 */

console.log('SQRT of 144 is ', Math.sqrt(144));
console.log('3 power of 9 is', Math.pow(3, 9));

console.log(Math.ceil(3.56));
console.log(Math.floor(3.51));

console.log('Random number 0-1:', Math.random());
console.log('Random number 0-10:', Math.round(Math.random() * 10));
console.log('Random number 0-100:', Math.round(Math.random() * 100));
