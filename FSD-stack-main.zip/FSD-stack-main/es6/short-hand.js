const x = 10,
  y = 20;

//   const numObj = {x: x, y: y}

const numObj = { x, y };

console.log(numObj);
