import { Person, addNumbers, PI } from './export-sample';

const personObj = new Person('Shiva', 'Mani');
personObj.printFullName();
